---
title: "Prerequisite — IAM & CLI"
date: 2026-07-01
weight: 2
chapter: false
pre: " <b> 5.2. </b> "
---

#### Region

All resources in this workshop are created in **Asia Pacific (Singapore) — `ap-southeast-1`**.

#### Create IAM users

1. Open **IAM → Users → Create user**
2. Create:
   + `dacswebsk-dev` — programmatic access for CLI / SDK (Console access disabled)
   + `dacswebsk-ses-smtp` — optional user for SES SMTP credentials
3. Attach AWS managed policies to `dacswebsk-dev` (direct attach):

```
AmazonAPIGatewayAdministrator
AmazonEC2FullAccess
AmazonRDSFullAccess
AmazonS3FullAccess
AmazonSESFullAccess
AmazonVPCFullAccess
AWSLambda_FullAccess
CloudWatchFullAccessV2
SecretsManagerReadWrite
```

![IAM users](/images/5-Workshop/5.2-Prerequisite/01-iam-users-list.png)

![IAM permissions for dacswebsk-dev](/images/5-Workshop/5.2-Prerequisite/02-iam-user-permissions-dacswebsk-dev.png)

#### Configure AWS CLI

```powershell
aws configure
```

```
Default region name: ap-southeast-1
Default output format: json
```

Verify identity:

```powershell
aws sts get-caller-identity
```

Expected ARN pattern:

```
arn:aws:iam::185529490133:user/dacswebsk-dev
```

#### Section summary

IAM user `dacswebsk-dev` provides least-privilege-enough access for deploying compute, database, storage, email, Lambda, and secrets. Secrets are never committed to source control; production connection strings later move to **Secrets Manager**.
