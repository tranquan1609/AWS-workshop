---
title: "Chuẩn bị — IAM & CLI"
date: 2026-07-01
weight: 2
chapter: false
pre: " <b> 5.2. </b> "
---

#### Region

Toàn bộ tài nguyên trong workshop được tạo tại **Asia Pacific (Singapore) —** `ap-southeast-1`.

#### Tạo IAM users

1. Mở **IAM → Users → Create user**
2. Tạo:
  - `dacswebsk-dev` — truy cập programmatic cho CLI / SDK (tắt Console access)
  - `dacswebsk-ses-smtp` — user tùy chọn cho SMTP SES
3. Gắn các AWS managed policies cho `dacswebsk-dev` (gắn trực tiếp):

```
AmazonAPIGatewayAdministrator
AmazonEC2FullAccess
AmazonRDSFullAccess
AmazonS3FullAccess
AmazonSESFullAccess
AmazonVPCFullAccess
AWSLambda_FullAccess
CloudWatchFullAccessV2
SecretsManagerReadWrite
```

![Danh sách IAM users](/images/5-Workshop/5.2-Prerequisite/01-iam-users-list.png)

![Quyền của dacswebsk-dev](/images/5-Workshop/5.2-Prerequisite/02-iam-user-permissions-dacswebsk-dev.png)

#### Cấu hình AWS CLI

```powershell
aws configure
```

```
Default region name: ap-southeast-1
Default output format: json
```

Kiểm tra identity:

```powershell
aws sts get-caller-identity
```

ARN kỳ vọng:

```
arn:aws:iam::185529490133:user/dacswebsk-dev
```



#### Section summary

IAM user `dacswebsk-dev` đủ quyền triển khai compute, database, storage, email, Lambda và secrets. Secret không commit vào source control; connection string production sau đó chuyển sang **Secrets Manager**.