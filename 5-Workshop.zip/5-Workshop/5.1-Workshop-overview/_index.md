---
title: "Workshop overview"
date: 2026-07-01
weight: 1
chapter: false
pre: " <b> 5.1. </b> "
---

#### About the project

**Event Management (DACSWEBSK)** manages events, attendees, schedules, videos, assignments, certificates, and notifications. The original stack used local SQL Server, local file uploads, and Gmail SMTP. This workshop moves those responsibilities to managed AWS services while keeping the ASP.NET Core MVC application.

#### Workshop goals

- Deploy a working cloud architecture for a real event/e-learning web app
- This project uses 15 services end-to-end
- Document each step with Console screenshots for the First Cloud Journey / FCAJ report
- Keep cost under the workshop budget by using Free Tier–friendly sizes (`t3.micro`, SQL Server Express, Shield Standard)



#### What you will build


| Layer      | Component                                                                         |
| ---------- | --------------------------------------------------------------------------------- |
| Network    | VPC `dacswebsk-vpc`, public subnets (2 AZs), private subnet, IGW, security groups |
| Data       | RDS SQL Server Express `dacswebsk-db`                                             |
| App        | EC2 `dacswebsk-app` running ASP.NET Core on port 80                               |
| Edge       | ALB + Target Group (healthy) + WAF                                                |
| Storage    | S3 buckets for events, videos, certificates, uploads                              |
| Email      | SES verified identity                                                             |
| Serverless | Lambda jobs + EventBridge cron + API Gateway chatbot                              |
| Ops        | Secrets Manager, CloudWatch, CloudTrail, AWS Backup                               |




#### Traffic flow

1. User opens the ALB DNS (optionally protected by WAF)
2. ALB forwards HTTP:80 to Target Group → EC2 app
3. App reads/writes business data on **RDS**
4. Event images upload to **S3**
5. Background tasks run on **Lambda** (triggered by **EventBridge**)
6. Chatbot calls **API Gateway** → **Lambda** → **RDS**



