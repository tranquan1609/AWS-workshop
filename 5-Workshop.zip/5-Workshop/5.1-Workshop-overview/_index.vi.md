---
title: "Tổng quan workshop"
date: 2026-07-01
weight: 1
chapter: false
pre: " <b> 5.1. </b> "
---

#### Giới thiệu dự án

**Event Management (DACSWEBSK)** quản lý sự kiện, người tham gia, lịch trình, video, bài thu hoạch, chứng chỉ và thông báo. Stack ban đầu dùng SQL Server local, upload file local và Gmail SMTP. Workshop này chuyển các trách nhiệm đó sang dịch vụ managed của AWS, vẫn giữ ứng dụng ASP.NET Core MVC.

#### Mục tiêu workshop

- Triển khai kiến trúc Cloud cho ứng dụng sự kiện / e-learning
- Dự án này sử dụng 15 dịch vụ end-to-end
- Ghi lại từng bước bằng screenshot Console cho báo cáo First Cloud Journey / FCAJ
- Kiểm soát chi phí trong ngân sách workshop: `t3.micro`, SQL Server Express, Shield Standard



#### Những gì sẽ được xây dựng


| Tầng       | Thành phần                                                                      |
| ---------- | ------------------------------------------------------------------------------- |
| Network    | VPC `dacswebsk-vpc`, subnet public (2 AZ), subnet private, IGW, security groups |
| Data       | RDS SQL Server Express `dacswebsk-db`                                           |
| App        | EC2 `dacswebsk-app` chạy ASP.NET Core cổng 80                                   |
| Edge       | ALB + Target Group (healthy) + WAF                                              |
| Storage    | S3 bucket cho sự kiện, video, chứng chỉ, upload                                 |
| Email      | SES identity đã verified                                                        |
| Serverless | Lambda jobs + EventBridge cron + API Gateway chatbot                            |
| Ops        | Secrets Manager, CloudWatch, CloudTrail, AWS Backup                             |




#### Luồng truy cập

1. Người dùng mở DNS ALB (có thể đi qua WAF)
2. ALB forward HTTP:80 tới Target Group → EC2 app
3. App đọc/ghi dữ liệu nghiệp vụ trên **RDS**
4. Ảnh sự kiện upload lên **S3**
5. Tác vụ nền chạy trên **Lambda** (kích hoạt bởi **EventBridge**)
6. Chatbot gọi **API Gateway** → **Lambda** → **RDS**

