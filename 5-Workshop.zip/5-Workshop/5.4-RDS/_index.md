---
title: "Amazon RDS (SQL Server)"
date: 2026-07-01
weight: 4
chapter: false
pre: " <b> 5.4. </b> "
---

#### Why SQL Server on RDS?

**Event Management (DACSWEBSK)** already uses **EF Core + SQL Server** and ASP.NET Identity. Moving to **Amazon RDS for SQL Server Express** keeps migrations compatible and only requires a connection string change.

#### Create the database

| Setting | Value |
|---------|-------|
| Engine | Microsoft SQL Server **Express Edition** |
| DB identifier | `dacswebsk-db` |
| Instance class | `db.t3.micro` |
| Storage | 20 GB (gp2/gp3) |
| Master username | `admin` |
| Region / AZ | `ap-southeast-1` |

![RDS Available](/images/5-Workshop/5.4-RDS/06-rds-databases-available.png)

#### Connectivity

+ Endpoint format: `dacswebsk-db.xxxxx.ap-southeast-1.rds.amazonaws.com`
+ Port: **1433**
+ Security group: `dacswebsk-rds-sg`

![RDS connectivity / endpoint](/images/5-Workshop/5.4-RDS/07-rds-connectivity-endpoint.png)

#### Security group inbound rules

Allow TCP **1433** from:

+ VPC CIDR `10.0.0.0/16`
+ EC2 Elastic IP (app host)
+ Admin workstation IP (temporary, for local migrate/test)
+ Optional demo rule for chatbot Lambda (tighten later for production)

![RDS SG inbound](/images/5-Workshop/5.4-RDS/08-rds-security-group-inbound-1433.png)

#### Application integration

Update `DefaultConnection` in configuration (later stored in Secrets Manager), then apply EF migrations:

```powershell
dotnet ef database update
```

Test by registering a user and creating an event from the Admin UI.

#### Section summary

RDS hosts all relational data (events, attendees, identity tables). Instance status **Available** plus inbound **1433** rules confirm the database tier is ready for the EC2 application.
