---
title: "Amazon RDS (SQL Server)"
date: 2026-07-01
weight: 4
chapter: false
pre: " <b> 5.4. </b> "
---

#### Vì sao dùng SQL Server trên RDS?

**Event Management (DACSWEBSK)** đã dùng **EF Core + SQL Server** và ASP.NET Identity. Chuyển sang **Amazon RDS for SQL Server Express** giữ nguyên migrations và chỉ cần đổi connection string.

#### Tạo database


| Mục             | Giá trị                                  |
| --------------- | ---------------------------------------- |
| Engine          | Microsoft SQL Server **Express Edition** |
| DB identifier   | `dacswebsk-db`                           |
| Instance class  | `db.t3.micro`                            |
| Storage         | 20 GB (gp2/gp3)                          |
| Master username | `admin`                                  |
| Region / AZ     | `ap-southeast-1`                         |


![RDS Available](/images/5-Workshop/5.4-RDS/06-rds-databases-available.png)

#### Connectivity

- Endpoint dạng: `dacswebsk-db.xxxxx.ap-southeast-1.rds.amazonaws.com`
- Port: **1433**
- Security group: `dacswebsk-rds-sg`

![RDS connectivity / endpoint](/images/5-Workshop/5.4-RDS/07-rds-connectivity-endpoint.png)

#### Inbound của security group

Cho phép TCP **1433** từ:

- CIDR VPC `10.0.0.0/16`
- Elastic IP của EC2 (host app)
- IP máy admin (tạm thời, để migrate/test local)
- Rule demo cho chatbot Lambda (nên siết lại khi production)

![RDS SG inbound](/images/5-Workshop/5.4-RDS/08-rds-security-group-inbound-1433.png)

#### Tích hợp ứng dụng

Cập nhật `DefaultConnection` trong cấu hình (sau đó lưu trong Secrets Manager), rồi chạy EF migrations:

```powershell
dotnet ef database update
```

Kiểm tra bằng cách đăng ký user và tạo sự kiện trên Admin UI.

#### Section summary

RDS lưu toàn bộ dữ liệu quan hệ (sự kiện, người tham gia, bảng Identity). Trạng thái **Available** cùng rule inbound **1433** xác nhận tầng database sẵn sàng cho ứng dụng trên EC2.