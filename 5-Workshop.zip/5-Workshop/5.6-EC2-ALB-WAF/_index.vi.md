---
title: "EC2, ALB & WAF"
date: 2026-07-01
weight: 6
chapter: false
pre: " <b> 5.6. </b> "
---

#### Amazon EC2 — host ứng dụng

Khởi tạo instance `dacswebsk-app`:


| Mục            | Giá trị                                           |
| -------------- | ------------------------------------------------- |
| Type           | `t3.micro`                                        |
| VPC / subnet   | `dacswebsk-vpc` / subnet public `ap-southeast-1a` |
| Security group | `dacswebsk-ec2-sg`                                |
| IAM role       | `DacsWebEc2Role`                                  |
| Elastic IP     | `18.140.214.160`                                  |


Publish app ASP.NET và chạy trên cổng **80**:

```bash
sudo nohup dotnet DACSWEBSK.dll --urls http://0.0.0.0:80 > app.log 2>&1 &
```

![EC2 Running](/images/5-Workshop/5.6-EC2-ALB-WAF/12-ec2-instance-running.png)

![EC2 instance summary](/images/5-Workshop/5.6-EC2-ALB-WAF/13-ec2-instance-summary-eip.png)

Truy cập thử trực tiếp: `http://18.140.214.160`

#### Application Load Balancer

Tạo ALB `dacswebsk-alb`:

- Scheme: Internet-facing
- AZ: `ap-southeast-1a` + `ap-southeast-1b`
- Listener: **HTTP:80** → forward tới target group `dacswebsk-tg`
- Target: EC2 `dacswebsk-app` cổng 80 — health status **Healthy**

![ALB Active](/images/5-Workshop/5.6-EC2-ALB-WAF/14-alb-active-listener.png)

![Target Group Healthy](/images/5-Workshop/5.6-EC2-ALB-WAF/15-target-group-healthy.png)

DNS ALB ví dụ:

```
http://dacswebsk-alb-1804460399.ap-southeast-1.elb.amazonaws.com
```

#### AWS WAF

Tạo protection pack `dacswebsk-waf` (Regional) với managed rule groups (**18 rules**) và associate với ALB.

![WAF protection pack](/images/5-Workshop/5.6-EC2-ALB-WAF/16-waf-protection-pack.png)

**Lưu ý workshop:** Common Rule Set (body size / XSS) có thể chặn POST form Admin kèm upload ảnh. Khi demo:

1. Override `SizeRestrictions_BODY` (và các rule BODY liên quan) sang **Count**
2. Tạm **Disassociate** WAF khỏi ALB khi test tạo sự kiện

#### Section summary

EC2 chạy ứng dụng MVC; ALB cung cấp DNS ổn định và health check qua nhiều AZ; WAF bảo vệ Layer-7 phía trước load balancer. Đây là tầng edge production của **Event Management (DACSWEBSK)** trên AWS.