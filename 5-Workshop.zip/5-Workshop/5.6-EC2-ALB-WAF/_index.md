---
title: "EC2, ALB & WAF"
date: 2026-07-01
weight: 6
chapter: false
pre: " <b> 5.6. </b> "
---

#### Amazon EC2 — application host

Launch instance `dacswebsk-app`:


| Setting        | Value                                             |
| -------------- | ------------------------------------------------- |
| Type           | `t3.micro`                                        |
| VPC / subnet   | `dacswebsk-vpc` / public subnet `ap-southeast-1a` |
| Security group | `dacswebsk-ec2-sg`                                |
| IAM role       | `DacsWebEc2Role`                                  |
| Elastic IP     | `18.140.214.160`                                  |


Publish the ASP.NET app and run it on port **80**:

```bash
sudo nohup dotnet DACSWEBSK.dll --urls http://0.0.0.0:80 > app.log 2>&1 &
```

EC2 runningEC2 instance summary

Direct access for smoke test: `http://18.140.214.160`

#### Application Load Balancer

Create ALB `dacswebsk-alb`:

- Scheme: Internet-facing
- AZs: `ap-southeast-1a` + `ap-southeast-1b`
- Listener: **HTTP:80** → forward to target group `dacswebsk-tg`
- Target: EC2 `dacswebsk-app` on port 80 — health status **Healthy**

ALB ActiveTarget Group Healthy

ALB DNS example:

```
http://dacswebsk-alb-1804460399.ap-southeast-1.elb.amazonaws.com
```



#### AWS WAF

Create protection pack `dacswebsk-waf` (Regional scope) with managed rule groups (**18 rules**) and associate it with the ALB.

WAF protection pack

**Workshop note:** Common Rule Set body size / XSS rules may block Admin multipart form POSTs (file upload). For the demo:

1. Override `SizeRestrictions_BODY` (and related BODY rules) to **Count**
2. Temporarily **Disassociate** WAF from the ALB while testing Admin create-event



#### Section summary

EC2 hosts the MVC app; ALB provides a stable entry DNS with health checks across AZs; WAF adds Layer-7 protection in front of the load balancer. Together this is the production-facing edge of **Event Management (DACSWEBSK)** on AWS.