---
title: "Lambda, EventBridge & Chatbot"
date: 2026-07-01
weight: 7
chapter: false
pre: " <b> 5.7. </b> "
---

#### Background jobs → serverless

On the original local demo, three .NET hosted services updated event status, generated certificates, and sent end-of-event notifications. On AWS they become **Lambda** functions (.NET 8) scheduled by **EventBridge**.

| Lambda function | Role |
|-----------------|------|
| `dacsweb-event-status-update` | Update event status from timeline |
| `dacsweb-auto-certificate` | Auto-generate certificates |
| `dacsweb-notification` | Notify after events end |
| `dacsweb-chatbot` | Chatbot API handler (RDS-backed) |

![Lambda functions](/images/5-Workshop/5.7-Lambda-EventBridge/17-lambda-functions-list.png)

#### EventBridge schedules

| Rule | Description | Status |
|------|-------------|--------|
| `dacsweb-event-status-cron` | Trigger status update every 5 min | Enabled |
| `dacsweb-certificate-cron` | Auto certificate every 15 min | Enabled |
| `dacsweb-notification-cron` | End-event notification every 5 min | Enabled |

![EventBridge rules](/images/5-Workshop/5.7-Lambda-EventBridge/19-eventbridge-scheduled-rules.png)

#### Chatbot via API Gateway

Flow:

```
Browser (site chatbot widget)
  → API Gateway POST /chat
  → Lambda dacsweb-chatbot
  → Amazon RDS
```

A Console test of `dacsweb-chatbot` returns **HTTP 200** with CORS headers, confirming the function is callable from the web frontend.

![Lambda chatbot test succeeded](/images/5-Workshop/5.7-Lambda-EventBridge/18-lambda-chatbot-test-success.png)

Chat API URL (example):

```
https://tcunvi9s86.execute-api.ap-southeast-1.amazonaws.com/chat
```

#### Section summary

EventBridge + Lambda replace in-process background services with scalable, pay-per-use jobs. The chatbot shows a second serverless path: API Gateway fronting Lambda that queries the same RDS database used by the MVC app.
