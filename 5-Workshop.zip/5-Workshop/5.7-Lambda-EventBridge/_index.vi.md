---
title: "Lambda, EventBridge & Chatbot"
date: 2026-07-01
weight: 7
chapter: false
pre: " <b> 5.7. </b> "
---

#### Background jobs → serverless

Trên demo local, ba hosted service .NET cập nhật trạng thái sự kiện, tạo chứng chỉ và gửi thông báo kết thúc. Trên AWS chúng trở thành function **Lambda** (.NET 8) được lên lịch bởi **EventBridge**.

| Lambda function | Vai trò |
|-----------------|---------|
| `dacsweb-event-status-update` | Cập nhật trạng thái sự kiện theo thời gian |
| `dacsweb-auto-certificate` | Tự sinh chứng chỉ |
| `dacsweb-notification` | Thông báo sau khi sự kiện kết thúc |
| `dacsweb-chatbot` | Handler API chatbot (truy vấn RDS) |

![Danh sách Lambda](/images/5-Workshop/5.7-Lambda-EventBridge/17-lambda-functions-list.png)

#### Lịch EventBridge

| Rule | Mô tả | Status |
|------|-------|--------|
| `dacsweb-event-status-cron` | Cập nhật trạng thái mỗi 5 phút | Enabled |
| `dacsweb-certificate-cron` | Tự sinh chứng chỉ mỗi 15 phút | Enabled |
| `dacsweb-notification-cron` | Thông báo kết thúc mỗi 5 phút | Enabled |

![EventBridge rules](/images/5-Workshop/5.7-Lambda-EventBridge/19-eventbridge-scheduled-rules.png)

#### Chatbot qua API Gateway

Luồng:

```
Browser (widget chatbot trên site)
  → API Gateway POST /chat
  → Lambda dacsweb-chatbot
  → Amazon RDS
```

Test trên Console của `dacsweb-chatbot` trả về **HTTP 200** kèm header CORS, xác nhận frontend web gọi được function.

![Lambda chatbot test thành công](/images/5-Workshop/5.7-Lambda-EventBridge/18-lambda-chatbot-test-success.png)

URL Chat API (ví dụ):

```
https://tcunvi9s86.execute-api.ap-southeast-1.amazonaws.com/chat
```

#### Section summary

EventBridge + Lambda thay background service trong process bằng job serverless, trả theo mức dùng. Chatbot là đường serverless thứ hai: API Gateway đứng trước Lambda, truy vấn cùng RDS mà ứng dụng MVC đang dùng.
