---
title: "Amazon S3 & SES"
date: 2026-07-01
weight: 5
chapter: false
pre: " <b> 5.5. </b> "
---

#### Amazon S3 — lưu trữ đối tượng

Tạo các bucket riêng (private, Block Public Access ON):

| Bucket | Mục đích |
|--------|----------|
| `dacswebsk-images-quan` | Ảnh sự kiện |
| `dacswebsk-videos-quan` | Video học tập |
| `dacswebsk-certificates-quan` | Chứng chỉ tạo ra |
| `dacswebsk-uploads-quan` | Upload bài tập / minh chứng |

![Danh sách S3 buckets](/images/5-Workshop/5.5-S3-SES/09-s3-buckets-list.png)

#### Kiểm tra upload

Sau khi tạo sự kiện kèm ảnh trong Admin, object xuất hiện dưới prefix `events/`:

![Object sự kiện trên S3](/images/5-Workshop/5.5-S3-SES/10-s3-events-objects-uploaded.png)

Ứng dụng ASP.NET dùng `IFileStorageService` với provider **S3** để upload không còn phụ thuộc đĩa EC2, mà thành object bền vững trên Cloud.

#### Amazon SES — email

1. Mở **SES → Verified identities**
2. Verify email gửi đi (ví dụ: `testmailxn@gmail.com`)
3. Status phải là **Verified**
4. Gửi test email từ Console hoặc kích hoạt mail xác nhận từ app

![SES identity Verified](/images/5-Workshop/5.5-S3-SES/11-ses-identity-verified.png)

> Lưu ý: Tài khoản AWS mới thường ở **sandbox** SES (chỉ gửi được tới địa chỉ đã verify). Request production access khi cần.

#### Section summary

S3 thay upload local trong `wwwroot`; SES thay Gmail SMTP. Hai dịch vụ này loại bỏ hai phụ thuộc on-premises lớn của demo ban đầu.
