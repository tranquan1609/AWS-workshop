---
title: "Amazon S3 & SES"
date: 2026-07-01
weight: 5
chapter: false
pre: " <b> 5.5. </b> "
---

#### Amazon S3 — object storage

Create dedicated buckets (private, Block Public Access ON):

| Bucket | Purpose |
|--------|---------|
| `dacswebsk-images-quan` | Event images |
| `dacswebsk-videos-quan` | Learning videos |
| `dacswebsk-certificates-quan` | Generated certificates |
| `dacswebsk-uploads-quan` | Assignments / evidence uploads |

![S3 buckets](/images/5-Workshop/5.5-S3-SES/09-s3-buckets-list.png)

#### Upload verification

After creating an event with an image in Admin, objects appear under the `events/` prefix:

![S3 event objects](/images/5-Workshop/5.5-S3-SES/10-s3-events-objects-uploaded.png)

The ASP.NET app uses `IFileStorageService` with provider **S3** so uploads leave the EC2 disk and become durable cloud objects.

#### Amazon SES — email

1. Open **SES → Verified identities**
2. Verify sender email (example: `testmailxn@gmail.com`)
3. Status must be **Verified**
4. Send a test email from Console or trigger confirmations from the app

![SES verified identity](/images/5-Workshop/5.5-S3-SES/11-ses-identity-verified.png)

> Note: New AWS accounts may start in the SES **sandbox** (can only send to verified addresses). Request production access when needed.

#### Section summary

S3 replaces local `wwwroot` uploads for durable media. SES replaces Gmail SMTP for transactional mail. Together they remove two major on-premises dependencies from the original demo.
