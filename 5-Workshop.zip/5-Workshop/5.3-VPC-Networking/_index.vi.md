---
title: "VPC & mạng"
date: 2026-07-01
weight: 3
chapter: false
pre: " <b> 5.3. </b> "
---

#### Tạo VPC

Tạo VPC **`dacswebsk-vpc`** với cấu hình:

| Mục | Giá trị |
|-----|---------|
| IPv4 CIDR | `10.0.0.0/16` |
| DNS resolution | Enabled |
| DNS hostnames | Enabled |
| Internet Gateway | `dacswebsk-igw` |

![Resource map VPC](/images/5-Workshop/5.3-VPC-Networking/03-vpc-dacswebsk-resource-map.png)

#### Subnets

| Subnet | AZ | CIDR | Vai trò |
|--------|----|------|---------|
| `dacswebsk-subnet-public1-ap-southeast-1a` | `ap-southeast-1a` | `10.0.0.0/20` | EC2 + ALB |
| `dacswebsk-subnet-public2-ap-southeast-1b` | `ap-southeast-1b` | `10.0.16.0/20` | ALB (AZ thứ 2) |
| `dacswebsk-subnet-private1-ap-southeast-1a` | `ap-southeast-1a` | `10.0.128.0/20` | Workload private (tuỳ chọn) |

Subnet public dùng route table **`dacswebsk-rtb-public`** trỏ `0.0.0.0/0` tới Internet Gateway.

![Subnets](/images/5-Workshop/5.3-VPC-Networking/04-vpc-subnets-public-private.png)

#### Security groups

| Security group | Mục đích |
|----------------|----------|
| `dacswebsk-alb-sg` | Cho phép HTTP 80 từ Internet vào ALB |
| `dacswebsk-ec2-sg` | Cho phép HTTP 80 từ ALB SG; SSH/RDP từ IP admin |
| `dacswebsk-rds-sg` | Cho phép MSSQL 1433 từ VPC / EC2 / Lambda khi cần |
| `dacswebsk-lambda-sg` | Outbound cho Lambda cần truy cập VPC |

![Security groups](/images/5-Workshop/5.3-VPC-Networking/05-vpc-security-groups.png)

#### Section summary

Thiết kế VPC đặt web tier trên subnet public thuộc **hai Availability Zones** để ALB đáp ứng yêu cầu multi-AZ; security groups kiểm soát luồng traffic theo nguyên tắc ít quyền nhất: ALB → EC2 → RDS.
