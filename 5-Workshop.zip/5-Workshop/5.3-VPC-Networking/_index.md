---
title: "VPC & Networking"
date: 2026-07-01
weight: 3
chapter: false
pre: " <b> 5.3. </b> "
---

#### Create VPC

Create VPC **`dacswebsk-vpc`** with:

| Setting | Value |
|---------|-------|
| IPv4 CIDR | `10.0.0.0/16` |
| DNS resolution | Enabled |
| DNS hostnames | Enabled |
| Internet Gateway | `dacswebsk-igw` |

![VPC resource map](/images/5-Workshop/5.3-VPC-Networking/03-vpc-dacswebsk-resource-map.png)

#### Subnets

| Subnet | AZ | CIDR | Role |
|--------|----|------|------|
| `dacswebsk-subnet-public1-ap-southeast-1a` | `ap-southeast-1a` | `10.0.0.0/20` | EC2 + ALB |
| `dacswebsk-subnet-public2-ap-southeast-1b` | `ap-southeast-1b` | `10.0.16.0/20` | ALB (2nd AZ) |
| `dacswebsk-subnet-private1-ap-southeast-1a` | `ap-southeast-1a` | `10.0.128.0/20` | Optional private workloads |

Public subnets use route table **`dacswebsk-rtb-public`** pointing `0.0.0.0/0` to the Internet Gateway.

![Subnets](/images/5-Workshop/5.3-VPC-Networking/04-vpc-subnets-public-private.png)

#### Security groups

| Security group | Purpose |
|----------------|---------|
| `dacswebsk-alb-sg` | Allow HTTP 80 from Internet to ALB |
| `dacswebsk-ec2-sg` | Allow HTTP 80 from ALB SG; SSH/RDP from admin IP |
| `dacswebsk-rds-sg` | Allow MSSQL 1433 from VPC / EC2 / Lambda as needed |
| `dacswebsk-lambda-sg` | Outbound for Lambda functions that need VPC access |

![Security groups](/images/5-Workshop/5.3-VPC-Networking/05-vpc-security-groups.png)

#### Section summary

The VPC design places the web tier in public subnets across **two Availability Zones** so the ALB can meet multi-AZ requirements, while security groups enforce least-privilege traffic between ALB → EC2 → RDS.
