---
title: "Monitoring & bảo mật vận hành"
date: 2026-07-01
weight: 8
chapter: false
pre: " <b> 5.8. </b> "
---

#### AWS Secrets Manager

Lưu cấu hình production (connection string RDS, cấu hình SES) trong secret `dacswebskproduction`. **Không** commit secret vào Git hay chỉ để trong `appsettings.json`.

Secrets Manager

#### AWS Backup

Tạo backup plan `dacswebsk-backup-plan` với rule daily và resource assignment `dacswebsk-rds` để bảo vệ instance SQL Server.

Backup plan

#### AWS CloudTrail

Bật trail `dacswebsk-trail`:

- Trail logging: **ON**
- Multi-region trail: Yes
- Ghi log vào bucket S3 của CloudTrail

CloudTrail logging

#### Amazon CloudWatch Alarms

Tạo alarm cho storage / connection RDS và status check EC2. Overview hiển thị các dịch vụ ở trạng thái **OK** (ví dụ: free storage RDS, StatusCheckFailed EC2 = 0).

![CloudWatch alarms OK](/images/5-Workshop/5.8-Monitoring-Security/23-cloudwatch-alarms-ok.png

#### Ghi chú tuỳ chọn cho báo cáo


| Chủ đề            | Quyết định trong workshop                                                                               |
| ----------------- | ------------------------------------------------------------------------------------------------------- |
| AWS Shield        | **Shield Standard** (miễn phí, mặc định) bảo vệ ALB / EIP trước DDoS L3/L4 phổ biến                     |
| Route 53          | Bỏ qua (chưa có domain riêng); dùng DNS ALB để truy cập                                                 |
| WAF vs form Admin | Managed rules có thể chặn POST multipart — override rule BODY sang Count hoặc tạm disassociate khi demo |




#### Section summary

Secrets Manager loại bỏ credential hardcode, Backup bảo vệ database, CloudTrail ghi lại hoạt động API, CloudWatch alarms cung cấp quan sát vận hành — khép vòng observability và governance cho **Event Management (DACSWEBSK)** trên AWS.