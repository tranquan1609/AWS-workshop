---
title: "Monitoring & Security Ops"
date: 2026-07-01
weight: 8
chapter: false
pre: " <b> 5.8. </b> "
---

#### AWS Secrets Manager

Store production configuration (RDS connection string, SES-related settings) in secret **`dacswebskproduction`**. Do **not** commit secrets to Git or leave them only in `appsettings.json`.

![Secrets Manager](/images/5-Workshop/5.8-Monitoring-Security/20-secrets-manager-dacswebskproduction.png)

#### AWS Backup

Create backup plan **`dacswebsk-backup-plan`** with daily rule and resource assignment **`dacswebsk-rds`** so the SQL Server instance is protected.

![Backup plan](/images/5-Workshop/5.8-Monitoring-Security/21-backup-plan-rds.png)

#### AWS CloudTrail

Enable trail **`dacswebsk-trail`**:

+ Trail logging: **ON**
+ Multi-region trail: Yes
+ Delivery to S3 CloudTrail logs bucket

![CloudTrail logging](/images/5-Workshop/5.8-Monitoring-Security/22-cloudtrail-logging-on.png)

#### Amazon CloudWatch Alarms

Create alarms for RDS storage / connections and EC2 status checks. Overview shows services in **OK** state (example: RDS free storage, EC2 status check failed = 0).

![CloudWatch alarms OK](/images/5-Workshop/5.8-Monitoring-Security/23-cloudwatch-alarms-ok.png)

#### Optional notes for the report

| Topic | Decision in this workshop |
|-------|---------------------------|
| AWS Shield | **Shield Standard** (included, free) protects ALB / EIP against common L3/L4 DDoS |
| Route 53 | Skipped (no custom domain); ALB DNS is used for access |
| WAF vs Admin forms | Managed rules may block multipart POSTs — override BODY rules to Count or temporarily disassociate for demo |

#### Section summary

Secrets Manager removes hardcoded credentials, Backup protects the database, CloudTrail records API activity, and CloudWatch alarms provide operational visibility — closing the observability and governance loop for **Event Management (DACSWEBSK)** on AWS.
