---
title: "Dọn dẹp tài nguyên"
date: 2026-07-01
weight: 9
chapter: false
pre: " <b> 5.9. </b> "
---

#### Vì sao cần dọn dẹp?

ALB và WAF vẫn tính phí ngay cả khi traffic thấp. Sau khi chụp ảnh và hoàn tất báo cáo, hãy xoá tài nguyên không còn dùng để tránh phát sinh chi phí ngoài dự kiến.

#### Thứ tự xoá gợi ý

1. Disassociate và xoá WAF protection pack `dacswebsk-waf`
2. Xoá ALB `dacswebsk-alb` và Target Group `dacswebsk-tg`
3. Disable/xoá EventBridge rules, rồi xoá Lambda + API Gateway
4. Xoá CloudWatch alarms
5. Stop/xoá EC2 `dacswebsk-app` và release Elastic IP
6. (Tuỳ chọn) tạo snapshot RDS cuối, rồi xoá `dacswebsk-db`
7. Empty và xoá S3 buckets (giữ bucket log CloudTrail nếu còn cần)
8. Xoá Secrets Manager secret, Backup assignment, CloudTrail trail
9. Xoá security groups, subnets, IGW, VPC



#### Giữ lại tạm (tuỳ chọn)

- Chỉ giữ EC2 + RDS + S3
- Xoá ALB + WAF trước (thường là phần tốn chi phí edge nhiều nhất theo ngày)



#### Checklist sau khi dọn

```powershell
aws ec2 describe-instances --region ap-southeast-1 --filters Name=tag:Name,Values=dacswebsk-app
aws rds describe-db-instances --region ap-southeast-1 --db-instance-identifier dacswebsk-db
aws elbv2 describe-load-balancers --region ap-southeast-1 --names dacswebsk-alb
```

Kỳ vọng “not found” / rỗng đối với tài nguyên bạn đã chủ động xoá.