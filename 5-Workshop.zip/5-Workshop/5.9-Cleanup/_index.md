---
title: "Cleanup"
date: 2026-07-01
weight: 9
chapter: false
pre: " <b> 5.9. </b> "
---

#### Why clean up?

ALB and WAF continue billing even when traffic is low. After screenshots and the report are done, delete unused resources to avoid unexpected cost.

#### Suggested delete order

1. Disassociate and delete WAF protection pack `dacswebsk-waf`
2. Delete ALB `dacswebsk-alb` and Target Group `dacswebsk-tg`
3. Disable/delete EventBridge rules, then delete Lambda functions + API Gateway
4. Delete CloudWatch alarms
5. Stop/delete EC2 `dacswebsk-app` and release Elastic IP
6. Take a final RDS snapshot (optional), then delete `dacswebsk-db`
7. Empty and delete S3 buckets (except keep CloudTrail logs if still required)
8. Delete Secrets Manager secret, Backup plan assignment, CloudTrail trail
9. Delete security groups, subnets, IGW, VPC

#### Keep for a short time (optional)

+ Keep EC2 + RDS + S3 only
+ Delete ALB + WAF first (~largest daily cost among edge services)

#### Checklist after cleanup

```powershell
aws ec2 describe-instances --region ap-southeast-1 --filters Name=tag:Name,Values=dacswebsk-app
aws rds describe-db-instances --region ap-southeast-1 --db-instance-identifier dacswebsk-db
aws elbv2 describe-load-balancers --region ap-southeast-1 --names dacswebsk-alb
```

Expect “not found” / empty for resources you intentionally removed.
